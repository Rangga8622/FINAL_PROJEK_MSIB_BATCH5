<?php $__env->startSection('content'); ?>
<?php
$ar_judul = ['No','Nama','Email','Role','IsActive','Terakhir Diubah','Action'];
$no = 1;
?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-light p-3 rounded">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"
                class="text-primary">Dashboard</a></li>
            <li class="breadcrumb-item active">Kelola User</li>
        </ol>
    </nav>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Kelola User</h4>
                <div class="d-flex justify-content-between mb-2">
                    
                    
                </div>
                <div class="table-responsive">
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($jdl); ?></th>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $ar_user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($u->name); ?></td>
                            <td><?php echo e($u->email); ?></td>
                            <td><?php echo e($u->role); ?></td>
                            <td><?php echo e($u->isactive); ?></td>
                            <td><?php echo e($u->updated_at); ?></td>
                                    <td>
                              <form method="POST" action="<?php echo e(route('user.destroy', $u->id)); ?>">
                              <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>		
                              
                                        <a class="btn btn-warning btn-sm" href="<?php echo e(route('user.edit', $u->id)); ?>" title="Ubah User">
                                            <i class="bi bi-pencil-fill"></i>
                                        </a>
                                        <button type="submit" title="Hapus User" class="btn btn-danger btn-sm"
                                        name="proses" value="hapus"
                                        onclick="return confirm('Anda Yakin diHapus?')">
                                        <i class="bi bi-trash"></i>
                                    </button>
                              </form>
                            </td>
                          </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/user/index.blade.php ENDPATH**/ ?>