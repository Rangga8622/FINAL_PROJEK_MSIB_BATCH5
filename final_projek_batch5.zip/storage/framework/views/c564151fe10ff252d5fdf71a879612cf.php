<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Data Pendaftaran</title>


    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h2 {
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th,
        td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #f4f4f4;
            color: #333;
        }

        img {
            max-width: 100px;
            max-height: 100px;
        }
    </style>
</head>

<body>
    <h2>Data Pendaftaran</h2>

    <?php if(!empty($search)): ?>
        <h3>Hasil Pencarian untuk: <?php echo e($search); ?></h3>
    <?php else: ?>
        <h3>Seluruh Data Pendaftaran</h3>
    <?php endif; ?>

    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Mahasiswa</th>
                <th>Organisasi</th>
                <th>Tanggal Pendaftaran</th>
                <th>Status Pendaftaran</th>

            </tr>
        </thead>
        <tbody>
            <?php
                $no = 1;
            ?>
            <?php $__currentLoopData = $ar_pendaftaran_pdf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e(optional($p->mahasiswa)->nama); ?></td>
                    <td><?php echo e(optional($p->mahasiswa->organisasi)->nama); ?></td>
                    <td><?php echo e(optional($p->mahasiswa)->tanggal_pendaftaran); ?></td>
                    <td><?php echo e($p->status_pendaftaran); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/pendaftaran/PDF.blade.php ENDPATH**/ ?>