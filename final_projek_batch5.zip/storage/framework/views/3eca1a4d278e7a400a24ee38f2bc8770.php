<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
    <nav aria-label="breadcrumb">
            <ol class="breadcrumb bg-light p-3 rounded">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"
                    class="text-primary">Dashboard</a></li>
                <li class="breadcrumb-item">
                <a href="<?php echo e(url('/pendaftaran')); ?>"
                    class="text-primary">Daftar Pendaftaran</a></li>
                <li class="breadcrumb-item active">Form Input</a></li>
            </ol>
        </nav>
        <div class="row">
            <div class="col-12 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        
                        
                        <h4 class="card-title">Form Mahasiswa</h4>
                        <form class="forms-sample" method="POST" action="<?php echo e(route('pendaftaran.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputName1">Name</label>
                                <select name="idmahasiswa"
                                    class="form-select <?php $__errorArgs = ['idmahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php else: ?> is-valid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option>-- Pilih Nama --</option>
                                    <?php $__currentLoopData = $ar_mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $sel = (old('idmahasiswa') == $m->id) ? 'selected' : ''; ?>
                                        <option value="<?php echo e($m->id); ?>" <?php echo e($sel); ?>><?php echo e($m->nama); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['idmahasiswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            
                            <div class="form-group">
                                <fieldset class="row mb-3">
                                    <legend class="col-form-label col-sm-2 pt-0">Status</legend>
                                    <div class="col-sm-10">
                                        <?php $__currentLoopData = $ar_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $cekStatus = (old('status_pendaftaran') == $s) ? 'checked' : ''; ?>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="status_pendaftaran"
                                                    value="<?php echo e($s); ?>" <?php echo e($cekStatus); ?>

                                                    id="<?php echo e($s); ?>">
                                                <label class="form-check-label" for="<?php echo e($s); ?>">
                                                    <?php echo e($s); ?>

                                                </label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </fieldset>
                                <?php $__errorArgs = ['status_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <font color="red"><?php echo e($message); ?></font>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <label for="ket">Keterangan</label>
                                <textarea class="form-control" name="keterangan" id="keterangan" rows="5" placeholder="Keterangan"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary me-2">Simpan</button>
                            <a href="<?php echo e(url('/pendaftaran')); ?>" class="btn btn-light">Kembali</a>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/pendaftaran/form.blade.php ENDPATH**/ ?>