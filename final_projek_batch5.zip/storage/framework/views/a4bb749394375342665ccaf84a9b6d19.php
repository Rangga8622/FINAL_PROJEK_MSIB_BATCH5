<?php $__env->startSection('content'); ?>
    <?php
        $ar_judul = ['No', 'Mahasiswa', 'Organisasi Pendaftaran', 'Status Pendaftaran', 'Keterangan', 'Action'];
        $no = $ar_pendaftaran->firstItem();
    ?>
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-light p-3 rounded">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"
                class="text-primary">Dashboard</a></li>
            <li class="breadcrumb-item active">Daftar Pendaftaran</li>
        </ol>
    </nav>
    <div class="col-lg-12 grid-margin stretch-card">
        <div class="card">
            <div class="card-body">
                <h4 class="card-title">Tabel Pendaftaran</h4>

                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-2">
                    <div>
                        <a href="<?php echo e(route('pendaftaran.create')); ?>" class="btn btn-primary btn-xs"
                            title="Tambah Data Pendaftaran">
                            <i class="bi bi-clipboard-plus"></i>
                            Tambah
                        </a>

                        <a href="<?php echo e(route('pendaftaran.pdf', ['search' => request('search')])); ?>"
                            class="btn btn-danger btn-xs" title="Eksport PDF Data Pendaftaran">
                            <i class="bi bi-file-type-pdf"></i>
                            PDF
                        </a>


                        <a href="<?php echo e(route('pendaftaran.excel')); ?>" class="btn btn-success btn-xs" title="Export To Excel">
                            <i class="bi bi-file-excel"></i>
                            EXCEL
                        </a>
                    </div>

                    <form action="<?php echo e(route('pendaftaran.index')); ?>" method="get" class="d-flex">
                        <input type="text" name="search" class="form-control form-control-sm"
                            value="<?php echo e(request('search')); ?>" />
                        <button type="submit" class="btn btn-primary btn-xs">
                            <div class="d-flex align-items-center">
                                <i class="bi bi-search"></i>
                                <span class="ms-1">Cari</span>
                            </div>
                        </button>
                    </form>

                </div>

                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <?php $__currentLoopData = $ar_judul; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jdl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($jdl); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ar_pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($no++); ?></td>
                                    <td><?php echo e($p->mahasiswa->nama); ?></td>
                                    <td><?php echo e($p->mahasiswa->organisasi->nama); ?></td>
                                    <td><?php echo e($p->status_pendaftaran); ?></td>
                                    <td><?php echo e($p->keterangan); ?></td>
                                    <td>
                                        <form method="POST" action="<?php echo e(route('pendaftaran.destroy', $p->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <a class="btn btn-info btn-xs" href="<?php echo e(route('pendaftaran.show', $p->id)); ?>"
                                                title="Detail Pendaftaran">
                                                <i class="bi bi-eye"></i>
                                            </a>
                                            <a class="btn btn-warning btn-xs"
                                                href="<?php echo e(route('pendaftaran.edit', $p->id)); ?>" title="Ubah Pendaftaran">
                                                <i class="bi bi-pencil-fill"></i>
                                            </a>
                                            <button type="submit" title="Hapus Mahasiswa" class="btn btn-danger btn-xs"
                                                name="proses" value="hapus"
                                                onclick="return confirm('Anda Yakin diHapus?')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="d-flex justify-content-end mt-5">
                        <?php echo e($ar_pendaftaran->links('pagination::bootstrap-5')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/pendaftaran/index.blade.php ENDPATH**/ ?>