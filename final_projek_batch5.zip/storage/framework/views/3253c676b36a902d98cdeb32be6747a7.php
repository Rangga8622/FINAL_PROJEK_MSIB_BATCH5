<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12 grid-margin">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h4 class="font-weight-bold mb-0">Dashboard</h4>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <p class="card-title text-md-center text-xl-left">Organisasi</p>
                        <div
                            class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                            <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0"><?php echo e($ar_organisasi); ?></h3>
                            <i class="bi bi-diagram-3-fill icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i>
                        </div>
                        <p class="mb-0 mt-2 text-danger">Jumlah organisasi</p>
                    </div>
                </div>
            </div>

            <div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                    <div class="card-body">
                        <p class="card-title text-md-center text-xl-left">Pendaftaran</p>
                        <div
                            class="d-flex flex-wrap justify-content-between justify-content-md-center justify-content-xl-between align-items-center">
                            <h3 class="mb-0 mb-md-2 mb-xl-0 order-md-1 order-xl-0"><?php echo e($ar_mahasiswa); ?></h3>
                            <i class="bi bi-people-fill icon-md text-muted mb-0 mb-md-3 mb-xl-0"></i>
                        </div>
                        <p class="mb-0 mt-2 text-danger">Jumlah Pendaftaran</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12 grid-margin grid-margin-lg-0 stretch-card">
                <div class="card">
                    <div class="card-body">
                        <h4 class="card-title">Grafik Pendaftaran dari masing-masing organisasi</h4>
                        <canvas id="myChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/3.7.0/chart.min.js"></script>

        <script>
            var lbl = [
                <?php $__currentLoopData = $ar_graph_organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    '<?php echo e($gb->nama_organisasi); ?>',
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ];
            var jml = [
                <?php $__currentLoopData = $ar_graph_organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    '<?php echo e($gb->total_pendaftaran_mahasiswa); ?>',
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ];
            document.addEventListener('DOMContentLoaded', function() {
                const data = {
                    labels: lbl,
                    datasets: [{
                        label: 'Perbandingan Jumlah pendaftaran',
                        data: jml,
                        backgroundColor: [
                            'rgb(255, 99, 132)',
                            'rgb(54, 162, 235)',
                            'rgb(255, 205, 86)',
                            'rgb(75, 192, 192)',
                            'rgb(153, 102, 255)',
                            'rgb(255, 159, 64)',
                            'rgb(255, 0, 0)',
                            'rgb(0, 255, 0)',
                            'rgb(0, 0, 255)',
                            'rgb(128, 128, 0)',
                            'rgb(255, 128, 0)',
                            'rgb(128, 0, 128)',
                            'rgb(0, 128, 128)',
                            'rgb(128, 128, 128)',
                            'rgb(0, 0, 0)',
                        ],
                        hoverOffset: 14
                    }]
                };

                const config = {
                    type: 'doughnut',
                    data: data,
                };

                const myChart = new Chart(document.getElementById('myChart'), config);
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>