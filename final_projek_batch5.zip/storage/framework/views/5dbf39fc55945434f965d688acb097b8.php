<!-- partial:partials/_navbar.html -->
<nav class="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
    <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-center">
        <a class="navbar-brand brand-logo me-10"><img src="<?php echo e(asset('backend/img/logo1.png')); ?>" class="me-2"
                alt="logo" /></a>
        <a class="navbar-brand brand-logo-mini"><img src="<?php echo e(asset('backend/img/logo.png')); ?>" alt="logo" /></a>
    </div>
    <div class="navbar-menu-wrapper d-flex align-items-center justify-content-end">
        <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-toggle="minimize">
            <span class="ti-view-list"></span>
        </button>

        <ul class="navbar-nav navbar-nav-right">

            <li class="nav-item nav-profile dropdown">

                <a class="nav-link dropdown-toggle" href="#" data-bs-toggle="dropdown" id="profileDropdown">
                    <?php if(empty(Auth::user()->foto)): ?>
                          <img src="<?php echo e(asset('backend/img/nophoto.jpg')); ?>" alt="Profile"
                              class="rounded-circle">
                      <?php else: ?>        
                          <img src="<?php echo e(asset('backend/img')); ?>/<?php echo e(Auth::user()->foto); ?>" alt="Profile"
                              class="rounded-circle">
                    <?php endif; ?>                
                </a>

                <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="profileDropdown">
                    <a class="dropdown-item" style="font-size: 20px">
                        <?php if(empty(Auth::user()->name)): ?>
                        <?php echo e(''); ?>

                        <?php else: ?>
                        <?php echo e(Auth::user()->name); ?>

                        <?php endif; ?>
                    </a>
                    <span class="dropdown-item">
                        <?php if(empty(Auth::user()->role)): ?>
                            ''
                        <?php else: ?>
                            <?php echo e(Auth::user()->role); ?>

                        <?php endif; ?>
                    </span>
                    <?php if(Auth::user()->role == 'admin'): ?>
                    <a class="dropdown-item" href="<?php echo e(url('/user')); ?>">
                        <i class="ti-settings text-primary"></i>
                        Kelola User
                    </a>
                    <?php elseif(Auth::user()->role == 'staff'): ?>
                    <a class="dropdown-item" href="">
                        <i class="ti-settings text-primary"></i>
                        Edit Profil
                    </a>
                    <?php endif; ?>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                  document.getElementById('logout-form').submit();">

                        <i class="ti-power-off text-primary"></i>
                        <?php echo e(__('Logout')); ?>

                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
            </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button"
            onclick="toggleSidebar()">
            <span class="ti-view-list"></span>
        </button>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/navbar.blade.php ENDPATH**/ ?>