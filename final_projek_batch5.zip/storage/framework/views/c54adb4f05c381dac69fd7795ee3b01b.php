<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb">
        <ol class="breadcrumb bg-light p-3 rounded">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/dashboard')); ?>"
                class="text-primary">Dashboard</a></li>
            <li class="breadcrumb-item">
            <a href="<?php echo e(url('/mahasiswa')); ?>"
                class="text-primary">Daftar Mahasiswa</a></li>
            <li class="breadcrumb-item active" aria-current="page">Detail</li>
        </ol>
    </nav>
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header text-white d-flex align-items-center justify-content-center">
                        <h1 class="card-title text-center fw-bold fs-2 m-0"><?php echo e($rs->nama); ?></h1>
                    </div>


                <div class="card-body">
                    <div class="text-center">

                        <?php if($rs->foto): ?>
                        <img src="<?php echo e(asset('backend/mhs/foto')); ?>/<?php echo e($rs->foto); ?>"
                            class="img-fluid rounded-circle mx-auto d-block" alt="<?php echo e($rs->nama); ?>'s Photo">
                        <?php else: ?>
                        <img src="<?php echo e(asset('backend/mhs/foto/noimage.png')); ?>"
                            class="img-fluid rounded-circle mx-auto d-block" alt="Default Image">
                        <?php endif; ?>
                    </div>


                    <ul class="list-group list-group-flush mt-4">
                        <li class="list-group-item">
                            <strong>Jurusan:</strong> <?php echo e($rs->jurusan->nama); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Daftar Organisasi:</strong> <?php echo e($rs->organisasi->nama); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Semester:</strong> <?php echo e($rs->semester); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Jenis Kelamin:</strong> <?php echo e($rs->gender); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>No HP:</strong> <?php echo e($rs->nohp); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Email:</strong> <?php echo e($rs->email); ?>

                        </li>
                        <li class="list-group-item">
                            <strong>Tanggal Pendaftaran:</strong> <?php echo e($rs->tanggal_pendaftaran); ?>

                        </li>

                        <li class="list-group-item">
                            <strong>CV:</strong>
                            <?php if($rs->cv): ?>
                            <a href="<?php echo e(asset('backend/mhs/cv')); ?>/<?php echo e($rs->cv); ?>" target="_blank"
                                class="btn btn-primary btn-xs">
                                <i class="bi bi-file-earmark-pdf-fill"></i> Download CV
                            </a>

                            <embed src="<?php echo e(asset('backend/mhs/cv')); ?>/<?php echo e($rs->cv); ?>" type="application/pdf"
                                style="display: none;" />
                            <?php else: ?>
                            <span class="text-muted">Tidak Ada CV</span>
                            <?php endif; ?>
                        </li>

                        <li class="list-group-item">
                            <strong>Barcode:</strong>
                            <div class="col-md-4">
                                <div class="card-body">
                                    <br />
                                    <?php
                                    $barcodeContent = $rs->id . '-' . date('Y') . '-' . $rs->nama . '-' . $rs->jurusan->nama . '-' . $rs->organisasi->nama;
                                    echo DNS2D::getBarcodeHTML($barcodeContent, 'QRCODE', 3, 3);
                                    ?>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>

                
                <div class="card-footer bg-white border-top">
                    <a href="<?php echo e(url('/mahasiswa')); ?>" class="btn btn-secondary d-block mx-auto">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/backend/mahasiswa/detail.blade.php ENDPATH**/ ?>