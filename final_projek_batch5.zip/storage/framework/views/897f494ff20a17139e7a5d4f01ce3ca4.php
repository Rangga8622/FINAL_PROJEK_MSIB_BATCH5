<footer class="page-footer bg-image" style="background-image: url(<?php echo e(asset('frontend/assets/img/world_pattern.svg')); ?>);">
    <div class="container-fluid">
        <div class="row mb-5">

            <div class="col-lg-3 py-3">
                <!-- konten dummy -->
            </div>

            <div class="col-lg-3 py-3">
                <!-- konten dummy -->
            </div>

            <div class="col-lg-3 py-3">
                <!-- konten dummy -->
            </div>

            <div class="col-lg-3 py-3">
                <!-- konten dummy -->
            </div>

        </div>
        <p class="text-center" id="copyright">Copyright &copy; . Kelompok 5 Final Projek Mentor 2
        </p>

    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/footer.blade.php ENDPATH**/ ?>