<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-white sticky" data-offset="500">
        <div class="container">
            <a href="#" class="navbar-brand">Org<span class="text-primary">Enroll.</span></a>

            <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="navbar-collapse collapse" id="navbarContent">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item ">
                        <a class="nav-link" href="<?php echo e(url('home')); ?>">Home</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('about')); ?>">About</a>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('contact')); ?>">Contact</a>
                    </li>

                    <?php if(auth()->guard()->guest()): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('blog')); ?>">Blog</a>
                        </li>


                        <?php if(Auth::user()->role == 'mahasiswa'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('form_mahasiswa.create')); ?>">Pendaftaran</a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('form_mahasiswa.index')); ?>">Pengumuman</a>
                            </li>


                            <li class="nav-item">
                                <a class="btn btn-primary ml-lg-2" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php elseif(Auth::user()->role == 'admin' || Auth::user()->role == 'staff'): ?>
                            <li class="nav-item">
                                <a class="btn btn-primary ml-lg-2" href="<?php echo e(url('dashboard')); ?>">Halaman Dasboard</a>
                            </li>
                            <li class="nav-item">
                                <a class="btn btn-primary ml-lg-2" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?></a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
</header>
<?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/header.blade.php ENDPATH**/ ?>