<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-banner">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-md-6">
                    <nav aria-label="Breadcrumb">
                        <ul class="breadcrumb justify-content-center py-0 bg-transparent">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Pendaftaran</li>
                        </ul>
                    </nav>
                    <h1 class="text-center">Formulir Pendaftaran</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="animate__animated animate__fadeIn animate__delay-1s">
        <div class="page-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">

                        <div class="card border-0">
                            <div class="card-header bg-primary text-center">
                                <h4 class="text-white">Isi Formulir Pendaftaran</h4>
                            </div>

                            <div class="card-body">
                                <form action="<?php echo e(route('mahasiswa.store_frontend')); ?>" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group">
                                        <label>Nama Lengkap</label>
                                        <input type="text" name="nama" class="form-control"
                                            placeholder="Masukan Nama Lengkap">
                                    </div>

                                    <div class="form-group">
                                        <label>Jurusan</label>
                                        <select name="idjurusan" class="form-control">
                                            <?php $__currentLoopData = $ar_jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jurusan->id); ?>"><?php echo e($jurusan->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Daftar Organisasi</label>
                                        <select name="idorganisasi" class="form-control">
                                            <?php $__currentLoopData = $ar_organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($organisasi->id); ?>"><?php echo e($organisasi->nama); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Semester</label>
                                        <input type="text" name="semester" class="form-control"
                                            placeholder="Masukan Semester">
                                    </div>

                                    <div class="form-group">
                                        <label>Gender</label>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="gender" id="male"
                                                value="L" checked>
                                            <label class="form-check-label" for="male"> Laki-Laki </label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="radio" name="gender" id="female"
                                                value="P">
                                            <label class="form-check-label" for="female"> Perempuan </label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <label>No Telepon</label>
                                        <input type="number" name="nohp" class="form-control"
                                            placeholder="Masukan No Telp">
                                    </div>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email" class="form-control"
                                            placeholder="Masukan Email">
                                    </div>

                                    <div class="form-group">
                                        <label>Tanggal Pendaftaran</label>
                                        <input type="date" name="tanggal_pendaftaran" class="form-control"
                                            placeholder="Masukan Tanggal Pendaftaran">
                                    </div>

                                    <div class="form-group">
                                        <label>CV</label>
                                        <input type="file" name="cv" class="form-control" accept=".pdf, .doc">
                                    </div>

                                    <div class="form-group">
                                        <label>Foto</label>
                                        <input type="file" name="foto" class="form-control" accept="image/*">
                                    </div>

                                    <button type="submit" class="btn btn-primary btn-block">
                                        Daftar Sekarang
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/pendaftaran.blade.php ENDPATH**/ ?>