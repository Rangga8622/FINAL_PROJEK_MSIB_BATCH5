<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-banner">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-md-6">
                    <nav aria-label="Breadcrumb">
                        <ul class="breadcrumb justify-content-center py-0 bg-transparent">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Pengumuman</li>
                        </ul>
                    </nav>
                    <h1 class="text-center">Pengumuman Proses Penerimaan</h1>
                </div>
            </div>
        </div>
    </div>
    <div class="page-section">
        <div class="container">

            <div class="row">
                <div class="col-md-12">
                    <?php if($message = Session::get('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <p><?php echo e($message); ?></p>
                            
                        </div>
                    <?php endif; ?>

                    <?php if($message = Session::get('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <p><?php echo e($message); ?></p>
                            
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Mahasiswa</th>
                                <th>Organisasi</th>
                                <th>Status Pendaftaran</th>
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $pendaftaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pendaftaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($pendaftaran->mahasiswa->nama); ?></td>
                                    <td><?php echo e($pendaftaran->mahasiswa->organisasi->nama); ?></td>
                                    <td><?php echo e($pendaftaran->status_pendaftaran ?: 'Belum diinput'); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/formpendaftaran/index.blade.php ENDPATH**/ ?>