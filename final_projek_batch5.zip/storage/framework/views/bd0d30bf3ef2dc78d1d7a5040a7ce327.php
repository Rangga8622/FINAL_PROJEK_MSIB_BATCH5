<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-banner">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-md-6">
                    <nav aria-label="Breadcrumb">
                        <ul class="breadcrumb justify-content-center py-0 bg-transparent">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('home')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Blog</li>
                        </ul>
                    </nav>
                    <h1 class="text-center">Blog</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="page-section">
        <div class="container">
            <div class="text-center wow fadeInUp">
                <div class="subhead">Our Blog</div>
                <h2 class="title-section">Read Latest News</h2>
                <div class="divider mx-auto"></div>
            </div>

            <div class="row mt-5">
                <?php $__currentLoopData = $ar_artikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 py-3 wow fadeInUp">
                        <div class="card-blog">
                            <div class="header">
                                <div class="post-thumb">
                                    
                                    <?php if($artikel->foto_header): ?>
                                        <img src="<?php echo e(asset('backend/artikel/foto_header')); ?>/<?php echo e($artikel->foto_header); ?>"
                                            alt="<?php echo e($artikel->nama); ?>">
                                    <?php else: ?>
                                        <img src="<?php echo e(asset('backend/artikel/foto_header/noimage.png')); ?>"
                                            alt="Default Image">
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="body">
                                <h5 class="post-title"><a
                                        href="<?php echo e(route('artikel.show', $artikel->id)); ?>"><?php echo e($artikel->judul); ?></a></h5>
                                <div class="post-date">Posted on <a href="#"><?php echo e($artikel->tanggal); ?></a></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="col-12 mt-4 text-center wow fadeInUp">
                <?php echo e($ar_artikel->links('pagination::bootstrap-5')); ?>

            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/blog.blade.php ENDPATH**/ ?>