<?php $__env->startSection('content'); ?>
    <div id="notfound">
        <div class="notfound">
            <div class="notfound-404">
                <h1>Acces Denied</h1>
            </div>
            <h2>Mohon Maaf Akun Anda tidak memiliki Akses ke Halaman ini</h2>

            <a href="<?php echo e(url('/home')); ?>">Kembali</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/access_denied.blade.php ENDPATH**/ ?>