<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="page-banner">
            <div class="row justify-content-center align-items-center h-100">
                <div class="col-md-6">
                    <nav aria-label="Breadcrumb">
                        <ul class="breadcrumb justify-content-center py-0 bg-transparent">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Home</a></li>
                            <li class="breadcrumb-item active">Pendaftaran</li>
                        </ul>
                    </nav>
                    <h1 class="text-center">Formulir Pendaftaran</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="animate__animated animate__fadeIn animate__delay-1s">
        <div class="page-section">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="card border-0">
                            <div class="card-header bg-primary text-center">
                                <h4 class="text-white">Isi Formulir Pendaftaran</h4>
                            </div>

                            <div class="card-body">
                                <form action="<?php echo e(route('form_mahasiswa.store')); ?>" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <!-- Form input -->
                                    <div class="form-group">
                                        <label>Nama Lengkap</label>
                                        <input type="text" name="nama"
                                            class="form-control <?php echo e($errors->has('nama') ? 'is-invalid' : ''); ?>"
                                            placeholder="Masukkan Nama Lengkap" value="<?php echo e(old('nama')); ?>">
                                        <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Jurusan</label>
                                        <select name="idjurusan"
                                            class="form-control <?php echo e($errors->has('idjurusan') ? 'is-invalid' : ''); ?>">
                                            <option value="">Pilih Jurusan</option>
                                            <?php $__currentLoopData = $ar_jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jurusan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($jurusan->id); ?>"
                                                    <?php echo e(old('idjurusan') == $jurusan->id ? 'selected' : ''); ?>>
                                                    <?php echo e($jurusan->nama); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['idjurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Daftar Organisasi</label>
                                        <select name="idorganisasi"
                                            class="form-control <?php echo e($errors->has('idorganisasi') ? 'is-invalid' : ''); ?>">
                                            <option value="">Pilih Organisasi</option>
                                            <?php $__currentLoopData = $ar_organisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $organisasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($organisasi->id); ?>"
                                                    <?php echo e(old('idorganisasi') == $organisasi->id ? 'selected' : ''); ?>>
                                                    <?php echo e($organisasi->nama); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['idorganisasi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Semester</label>
                                        <input type="text" name="semester"
                                            class="form-control <?php echo e($errors->has('semester') ? 'is-invalid' : ''); ?>"
                                            placeholder="Masukkan Semester" value="<?php echo e(old('semester')); ?>">
                                        <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <fieldset class="row mb-3">
                                            <legend class="col-form-label col-sm-2 pt-0">Gender</legend>
                                            <div class="col-sm-10">
                                                <?php $__currentLoopData = $ar_gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $cek = (old('gender') == $g) ? 'checked' : ''; ?>
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="gender"
                                                            value="<?php echo e($g); ?>" <?php echo e($cek); ?>>
                                                        <label class="form-check-label">
                                                            <?php echo e($g); ?>

                                                        </label>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </fieldset>
                                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <font color="red"><?php echo e($message); ?></font>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>No Telepon</label>
                                        <input type="number" name="nohp"
                                            class="form-control <?php echo e($errors->has('nohp') ? 'is-invalid' : ''); ?>"
                                            placeholder="Masukkan No Telp" value="<?php echo e(old('nohp')); ?>">
                                        <?php $__errorArgs = ['nohp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" name="email"
                                            class="form-control <?php echo e($errors->has('email') ? 'is-invalid' : ''); ?>"
                                            placeholder="Masukkan Email" value="<?php echo e(old('email')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group" hidden>
                                        <label>Tanggal Pendaftaran</label>
                                        <input type="date" name="tanggal_pendaftaran"
                                            class="form-control <?php echo e($errors->has('tanggal_pendaftaran') ? 'is-invalid' : ''); ?>"
                                            placeholder="Masukkan Tanggal Pendaftaran" readonly
                                            value="<?php echo e(date('d-F-Y H:i')); ?> WIB">
                                        <?php $__errorArgs = ['tanggal_pendaftaran'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>CV</label>
                                        <input type="file" name="cv"
                                            class="form-control <?php echo e($errors->has('cv') ? 'is-invalid' : ''); ?>"
                                            accept=".pdf, .doc">
                                        <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <div class="form-group">
                                        <label>Foto</label>
                                        <input type="file" name="foto"
                                            class="form-control <?php echo e($errors->has('foto') ? 'is-invalid' : ''); ?>"
                                            accept="image/*">
                                        <?php $__errorArgs = ['foto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>

                                    <!-- Form button -->
                                    <button type="submit" class="btn btn-primary btn-block">
                                        Daftar Sekarang
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/formpendaftaran/pendaftaran.blade.php ENDPATH**/ ?>