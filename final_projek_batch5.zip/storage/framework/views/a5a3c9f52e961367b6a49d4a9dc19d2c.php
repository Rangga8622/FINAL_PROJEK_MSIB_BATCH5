<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <meta name="copyright" content="MACode ID, https://macodeid.com/">

    <title>Pendaftaran Organisasi Mahasiswa di Kampus</title>

    <link href="<?php echo e(asset('frontend/assets/img/logo.png')); ?>" rel="icon">


    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/maicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/vendor/animate/animate.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('library/animate.min.css')); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

    <link href="https://fonts.googleapis.com/css?family=Maven+Pro:400,900" rel="stylesheet">
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('acces_denied/acces_denied.css')); ?>" />

</head>

<body>


    <?php echo $__env->make('frontend.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>


        <?php echo $__env->yieldContent('content'); ?>

    </main>


    <?php echo $__env->make('frontend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('frontend/assets/js/jquery-3.5.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/google-maps.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/vendor/wow/wow.min.js')); ?>"></script>
    <script src="<?php echo e(asset('frontend/assets/js/theme.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel\tugas_akhir_laravel\final_projek_batch5\resources\views/frontend/index.blade.php ENDPATH**/ ?>